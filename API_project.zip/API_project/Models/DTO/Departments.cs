﻿namespace API_project.Models.DTO
{
    public class Departments
    {
        public string Name { get; set; }
    }
}
